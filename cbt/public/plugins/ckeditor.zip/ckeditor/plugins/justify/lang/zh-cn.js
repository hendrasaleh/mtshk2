/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'justify', 'zh-cn', {
	block: '两端对齐',
	center: '居中',
	left: '左对齐',
	right: '右对齐'
} );
